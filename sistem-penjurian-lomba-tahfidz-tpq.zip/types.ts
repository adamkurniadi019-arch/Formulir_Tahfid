
export enum ClassType {
  IDAD = "I'dad",
  MEKKAH = "Mekkah",
  MADINAH = "Madinah"
}

export interface ScoreData {
  id: string;
  timestamp: number;
  nama: string;
  kelas: ClassType;
  kelancaran: number; // Max 40
  makhroj: number;    // Max 30
  tajwid: number;     // Max 20
  adab: number;       // Max 10
  total: number;      // Max 100
  catatan?: string;
}

export interface AppState {
  scores: ScoreData[];
}
