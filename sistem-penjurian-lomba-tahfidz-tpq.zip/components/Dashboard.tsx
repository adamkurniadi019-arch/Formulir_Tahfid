
import React from 'react';
import { ScoreData, ClassType } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie, Legend
} from 'recharts';

interface DashboardProps {
  scores: ScoreData[];
}

const Dashboard: React.FC<DashboardProps> = ({ scores }) => {
  const stats = React.useMemo(() => {
    const totalParticipants = scores.length;
    const avgScore = totalParticipants > 0 
      ? scores.reduce((acc, s) => acc + s.total, 0) / totalParticipants 
      : 0;
    
    const byClass = Object.values(ClassType).map(cls => {
      const classScores = scores.filter(s => s.kelas === cls);
      return {
        name: cls,
        count: classScores.length,
        avg: classScores.length > 0
          ? classScores.reduce((acc, s) => acc + s.total, 0) / classScores.length
          : 0,
        topThree: [...classScores].sort((a, b) => b.total - a.total).slice(0, 3)
      };
    });

    return { totalParticipants, avgScore, byClass };
  }, [scores]);

  const COLORS = ['#10b981', '#3b82f6', '#8b5cf6'];

  if (scores.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
        <div className="text-slate-400 mb-4">
          <svg className="w-16 h-16 mx-auto opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
        </div>
        <h2 className="text-xl font-medium text-slate-500">Belum Ada Statistik Tersedia</h2>
        <p className="text-slate-400">Silakan input data penilaian terlebih dahulu.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 text-sm font-medium">Total Santri Dinilai</p>
          <p className="text-4xl font-bold text-slate-800 mt-2">{stats.totalParticipants}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 text-sm font-medium">Rata-rata Nilai Keseluruhan</p>
          <p className="text-4xl font-bold text-emerald-600 mt-2">{stats.avgScore.toFixed(1)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Class Distribution Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Distribusi Peserta Per Kelas</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.byClass}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="count"
                >
                  {stats.byClass.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Avg Score per Class Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Rata-rata Skor Per Kelas</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.byClass}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip cursor={{fill: '#f8fafc'}} />
                <Bar dataKey="avg" name="Rata-rata" radius={[4, 4, 0, 0]}>
                  {stats.byClass.map((entry, index) => (
                    <Cell key={`cell-bar-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top Performers per Class */}
      <div className="space-y-6">
        <h3 className="text-xl font-bold text-slate-800 border-l-4 border-emerald-500 pl-3">Nilai Tertinggi Per Kelas</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.byClass.map((classStat, classIdx) => (
            <div key={classStat.name} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-slate-700 text-lg">Kelas {classStat.name}</h4>
                <span className="text-xs font-medium bg-slate-100 text-slate-500 px-2 py-1 rounded-md">
                  {classStat.count} Santri
                </span>
              </div>
              
              <div className="space-y-3 flex-1">
                {classStat.topThree.length > 0 ? (
                  classStat.topThree.map((s, idx) => (
                    <div key={s.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <div className="flex items-center space-x-3">
                        <div className={`w-6 h-6 flex items-center justify-center rounded-full text-[10px] font-bold text-white shadow-sm ${
                          idx === 0 ? 'bg-amber-400' :
                          idx === 1 ? 'bg-slate-400' :
                          'bg-orange-500'
                        }`}>
                          {idx + 1}
                        </div>
                        <p className="font-bold text-slate-800 text-sm truncate max-w-[100px]">{s.nama}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-black text-emerald-600">{s.total}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 text-sm italic text-center py-4">Belum ada data</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
