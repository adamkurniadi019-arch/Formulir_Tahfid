
import React from 'react';

interface NavbarProps {
  activeTab: 'form' | 'results' | 'dashboard';
  setActiveTab: (tab: 'form' | 'results' | 'dashboard') => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">Q</div>
            <span className="font-bold text-emerald-900 hidden sm:block">TahfidzJudge</span>
          </div>
          
          <div className="flex space-x-1 sm:space-x-4">
            <button
              onClick={() => setActiveTab('form')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'form' 
                  ? 'bg-emerald-100 text-emerald-700' 
                  : 'text-slate-600 hover:text-emerald-600'
              }`}
            >
              Input Nilai
            </button>
            <button
              onClick={() => setActiveTab('results')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'results' 
                  ? 'bg-emerald-100 text-emerald-700' 
                  : 'text-slate-600 hover:text-emerald-600'
              }`}
            >
              Spreadsheet
            </button>
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'dashboard' 
                  ? 'bg-emerald-100 text-emerald-700' 
                  : 'text-slate-600 hover:text-emerald-600'
              }`}
            >
              Dashboard
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
