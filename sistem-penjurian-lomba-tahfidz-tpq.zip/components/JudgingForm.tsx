
import React, { useState, useMemo } from 'react';
import { ClassType, ScoreData } from '../types';

interface JudgingFormProps {
  onSubmit: (data: Omit<ScoreData, 'id' | 'timestamp' | 'total'>) => void;
}

const JudgingForm: React.FC<JudgingFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    nama: '',
    kelas: ClassType.IDAD,
    kelancaran: 0,
    makhroj: 0,
    tajwid: 0,
    adab: 0,
    catatan: ''
  });

  const total = useMemo(() => {
    return Number(formData.kelancaran) + Number(formData.makhroj) + Number(formData.tajwid) + Number(formData.adab);
  }, [formData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama) return alert('Silakan masukkan nama santri');
    
    onSubmit({
      ...formData,
      kelancaran: Number(formData.kelancaran),
      makhroj: Number(formData.makhroj),
      tajwid: Number(formData.tajwid),
      adab: Number(formData.adab)
    });

    // Reset form
    setFormData({
      nama: '',
      kelas: ClassType.IDAD,
      kelancaran: 0,
      makhroj: 0,
      tajwid: 0,
      adab: 0,
      catatan: ''
    });
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: Number(value) }));
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-slate-200 space-y-6">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Nama Santri</label>
          <input
            type="text"
            required
            placeholder="Masukkan nama lengkap santri..."
            className="w-full px-4 py-2 bg-slate-800 text-white border border-slate-700 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all placeholder-slate-400"
            value={formData.nama}
            onChange={e => setFormData(prev => ({ ...prev, nama: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Kelas</label>
          <div className="grid grid-cols-3 gap-3">
            {Object.values(ClassType).map(cls => (
              <button
                key={cls}
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, kelas: cls }))}
                className={`py-2 px-4 rounded-lg text-sm font-medium border transition-all ${
                  formData.kelas === cls
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-300'
                }`}
              >
                {cls}
              </button>
            ))}
          </div>
        </div>
      </div>

      <hr className="border-slate-100" />

      <div className="space-y-6">
        <ScoreInput 
          label="Kelancaran Hafalan" 
          max={40} 
          value={formData.kelancaran} 
          name="kelancaran" 
          onChange={handleSliderChange} 
          color="emerald"
        />
        <ScoreInput 
          label="Makhroj & Ketepatan Ayat" 
          max={30} 
          value={formData.makhroj} 
          name="makhroj" 
          onChange={handleSliderChange} 
          color="blue"
        />
        <ScoreInput 
          label="Tajwid" 
          max={20} 
          value={formData.tajwid} 
          name="tajwid" 
          onChange={handleSliderChange} 
          color="indigo"
        />
        <ScoreInput 
          label="Adab & Sikap" 
          max={10} 
          value={formData.adab} 
          name="adab" 
          onChange={handleSliderChange} 
          color="amber"
        />
      </div>

      <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
        <div className="flex justify-between items-center">
          <span className="text-slate-600 font-medium">Total Skor:</span>
          <span className="text-3xl font-bold text-emerald-700">{total} / 100</span>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1">Catatan Tambahan (Opsional)</label>
        <textarea
          placeholder="Contoh: Terlalu cepat, kesalahan 1 kali..."
          className="w-full px-4 py-2 bg-slate-800 text-white border border-slate-700 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none h-24 placeholder-slate-400"
          value={formData.catatan}
          onChange={e => setFormData(prev => ({ ...prev, catatan: e.target.value }))}
        />
      </div>

      <button
        type="submit"
        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg active:transform active:scale-95"
      >
        Simpan Penilaian
      </button>
    </form>
  );
};

interface ScoreInputProps {
  label: string;
  max: number;
  value: number;
  name: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  color: 'emerald' | 'blue' | 'indigo' | 'amber';
}

const ScoreInput: React.FC<ScoreInputProps> = ({ label, max, value, name, onChange, color }) => {
  const colorMap = {
    emerald: 'accent-emerald-600 text-emerald-600',
    blue: 'accent-blue-600 text-blue-600',
    indigo: 'accent-indigo-600 text-indigo-600',
    amber: 'accent-amber-600 text-amber-600',
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <label className="font-semibold text-slate-700">{label}</label>
        <span className={`font-bold ${colorMap[color].split(' ')[1]}`}>{value} / {max}</span>
      </div>
      <input
        type="range"
        min="0"
        max={max}
        name={name}
        value={value}
        onChange={onChange}
        className={`w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer ${colorMap[color].split(' ')[0]}`}
      />
    </div>
  );
};

export default JudgingForm;
