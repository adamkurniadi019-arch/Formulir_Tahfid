
import React, { useState, useMemo } from 'react';
import { ScoreData, ClassType } from '../types';

interface ResultsTableProps {
  scores: ScoreData[];
  onDelete: (id: string) => void;
}

const ResultsTable: React.FC<ResultsTableProps> = ({ scores, onDelete }) => {
  const [filterKelas, setFilterKelas] = useState<ClassType | 'All'>('All');
  const [sortConfig, setSortConfig] = useState<{ key: keyof ScoreData; direction: 'asc' | 'desc' } | null>({ key: 'total', direction: 'desc' });

  const sortedAndFilteredScores = useMemo(() => {
    let result = [...scores];

    if (filterKelas !== 'All') {
      result = result.filter(s => s.kelas === filterKelas);
    }

    if (sortConfig) {
      result.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
        
        if (typeof aVal === 'string' && typeof bVal === 'string') {
          return sortConfig.direction === 'asc' 
            ? aVal.localeCompare(bVal) 
            : bVal.localeCompare(aVal);
        }
        
        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return sortConfig.direction === 'asc' ? aVal - bVal : bVal - aVal;
        }
        
        return 0;
      });
    }

    return result;
  }, [scores, filterKelas, sortConfig]);

  const handleSort = (key: keyof ScoreData) => {
    setSortConfig(prev => {
      if (prev?.key === key) {
        return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { key, direction: 'desc' };
    });
  };

  const exportCSV = () => {
    const headers = ['Nama', 'Kelas', 'Kelancaran', 'Makhroj', 'Tajwid', 'Adab', 'Total', 'Catatan'];
    const rows = sortedAndFilteredScores.map(s => [
      s.nama, s.kelas, s.kelancaran, s.makhroj, s.tajwid, s.adab, s.total, s.catatan || ''
    ]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `rekap_nilai_tahfidz_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <span className="text-sm font-medium text-slate-500">Filter Kelas:</span>
          <select 
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500"
            value={filterKelas}
            onChange={e => setFilterKelas(e.target.value as any)}
          >
            <option value="All">Semua Kelas</option>
            {Object.values(ClassType).map(cls => (
              <option key={cls} value={cls}>{cls}</option>
            ))}
          </select>
        </div>
        
        <button 
          onClick={exportCSV}
          disabled={scores.length === 0}
          className="w-full sm:w-auto px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 disabled:opacity-50 transition-colors flex items-center justify-center"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          Export CSV (Excel)
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-xs border-b border-slate-200">
            <tr>
              <th className="px-4 py-4 w-12 text-center">No</th>
              <th className="px-6 py-4 cursor-pointer hover:text-emerald-600" onClick={() => handleSort('nama')}>
                Nama {sortConfig?.key === 'nama' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
              </th>
              <th className="px-6 py-4 cursor-pointer hover:text-emerald-600" onClick={() => handleSort('kelas')}>
                Kelas {sortConfig?.key === 'kelas' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
              </th>
              <th className="px-6 py-4 text-center">Kelancaran</th>
              <th className="px-6 py-4 text-center">Makhroj</th>
              <th className="px-6 py-4 text-center">Tajwid</th>
              <th className="px-6 py-4 text-center">Adab</th>
              <th className="px-6 py-4 text-center cursor-pointer hover:text-emerald-600 font-bold" onClick={() => handleSort('total')}>
                Total {sortConfig?.key === 'total' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
              </th>
              <th className="px-6 py-4">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedAndFilteredScores.length > 0 ? (
              sortedAndFilteredScores.map((score, index) => (
                <tr key={score.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-4 py-4 text-center text-slate-400">{index + 1}</td>
                  <td className="px-6 py-4 font-semibold text-slate-800">{score.nama}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      score.kelas === ClassType.IDAD ? 'bg-blue-100 text-blue-700' :
                      score.kelas === ClassType.MEKKAH ? 'bg-amber-100 text-amber-700' :
                      'bg-purple-100 text-purple-700'
                    }`}>
                      {score.kelas}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center text-slate-600">{score.kelancaran}</td>
                  <td className="px-6 py-4 text-center text-slate-600">{score.makhroj}</td>
                  <td className="px-6 py-4 text-center text-slate-600">{score.tajwid}</td>
                  <td className="px-6 py-4 text-center text-slate-600">{score.adab}</td>
                  <td className="px-6 py-4 text-center">
                    <span className="font-bold text-emerald-600 text-lg">{score.total}</span>
                  </td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => onDelete(score.id)}
                      className="text-slate-300 hover:text-rose-500 p-2 transition-colors"
                      title="Hapus"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={9} className="px-6 py-12 text-center text-slate-400 italic">
                  Belum ada data penilaian yang tersimpan.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ResultsTable;
