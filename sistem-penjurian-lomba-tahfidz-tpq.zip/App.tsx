
import React, { useState, useEffect } from 'react';
import { ScoreData, ClassType } from './types';
import Navbar from './components/Navbar';
import JudgingForm from './components/JudgingForm';
import ResultsTable from './components/ResultsTable';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'form' | 'results' | 'dashboard'>('form');
  const [scores, setScores] = useState<ScoreData[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('tahfidz_scores');
    if (saved) {
      try {
        setScores(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load scores", e);
      }
    }
  }, []);

  // Save to localStorage whenever scores change
  useEffect(() => {
    localStorage.setItem('tahfidz_scores', JSON.stringify(scores));
  }, [scores]);

  const handleAddScore = (data: Omit<ScoreData, 'id' | 'timestamp' | 'total'>) => {
    const total = data.kelancaran + data.makhroj + data.tajwid + data.adab;
    const newScore: ScoreData = {
      ...data,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      total
    };
    setScores(prev => [newScore, ...prev]);
    setActiveTab('results');
  };

  const handleDeleteScore = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
      setScores(prev => prev.filter(s => s.id !== id));
    }
  };

  const handleClearAll = () => {
    if (confirm('HAPUS SEMUA DATA? Tindakan ini tidak dapat dibatalkan.')) {
      setScores([]);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="container mx-auto px-4 pt-6">
        {activeTab === 'form' && (
          <div className="max-w-2xl mx-auto">
            <header className="mb-8 text-center">
              <h1 className="text-3xl font-bold text-emerald-800">Penilaian Tahfidz</h1>
              <p className="text-slate-500">TPQ Masjid Jami' Assegaff • 2026/2027</p>
            </header>
            <JudgingForm onSubmit={handleAddScore} />
          </div>
        )}

        {activeTab === 'results' && (
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-slate-800">Tabel Hasil Penilaian</h1>
                <p className="text-slate-500 text-sm">Rekapitulasi nilai santri secara real-time</p>
              </div>
              <button 
                onClick={handleClearAll}
                className="px-4 py-2 bg-rose-50 text-rose-600 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors text-sm font-medium"
              >
                Reset Data
              </button>
            </div>
            <ResultsTable 
              scores={scores} 
              onDelete={handleDeleteScore} 
            />
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="max-w-6xl mx-auto">
            <h1 className="text-2xl font-bold text-slate-800 mb-6">Statistik & Ringkasan</h1>
            <Dashboard scores={scores} />
          </div>
        )}
      </main>
      
      {/* Footer Branding */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-4 text-center text-xs text-slate-400">
        © 2026 Lomba Tahfidz Al-Qur’an Tingkat TPQ - Juknis v1.0
      </footer>
    </div>
  );
};

export default App;
